# 📦 คู่มือการติดตั้ง SoraGen

เว็บแอพสร้างวีดีโอด้วย AI ผ่าน OpenAI Sora API

---

## 📋 สิ่งที่ต้องมีก่อนติดตั้ง

1. **Python 3.8 ขึ้นไป**
2. **OpenAI API Key** (ต้องมี access ถึง Sora API)
3. **ตัวจัดการ package**: pip
4. **เบราว์เซอร์**: Chrome, Firefox, Safari หรือ Edge

---

## 🪟 การติดตั้งบน Windows

### ขั้นตอนที่ 1: ติดตั้ง Python

1. ดาวน์โหลด Python จาก https://www.python.org/downloads/
2. **สำคัญ!** เมื่อติดตั้งให้เลือก **"Add Python to PATH"**
3. กดปุ่ม Install

**ตรวจสอบการติดตั้ง:**
```cmd
python --version
pip --version
```

### ขั้นตอนที่ 2: แตกไฟล์โปรเจกต์

1. แตกไฟล์ `SoraGen.zip` ไปยังโฟลเดอร์ที่ต้องการ (เช่น `C:\SoraGen`)
2. เปิด Command Prompt (กด Windows + R แล้วพิมพ์ `cmd`)
3. เข้าไปยังโฟลเดอร์โปรเจกต์:
```cmd
cd C:\SoraGen
```

### ขั้นตอนที่ 3: ติดตั้ง Dependencies

```cmd
pip install -r requirements.txt
```

### ขั้นตอนที่ 4: ตั้งค่า API Key

1. คัดลอกไฟล์ตัวอย่าง:
```cmd
copy .env.example .env
```

2. แก้ไขไฟล์ `.env` ด้วย Notepad:
```cmd
notepad .env
```

3. ใส่ OpenAI API Key ของคุณ:
```
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxx
```

4. กด Ctrl+S เพื่อบันทึก และปิด Notepad

### ขั้นตอนที่ 5: รันโปรแกรม

```cmd
python main.py
```

**เปิดเบราว์เซอร์ไปที่:** http://127.0.0.1:8000

**หยุดโปรแกรม:** กด `Ctrl+C` ใน Command Prompt

---

## 🍎 การติดตั้งบน macOS

### ขั้นตอนที่ 1: ติดตั้ง Python

**ตรวจสอบ Python ที่มีอยู่:**
```bash
python3 --version
```

**ถ้ายังไม่มี Python 3:**

**วิธีที่ 1: ใช้ Homebrew (แนะนำ)**
```bash
# ติดตั้ง Homebrew (ถ้ายังไม่มี)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# ติดตั้ง Python
brew install python@3.11
```

**วิธีที่ 2: ดาวน์โหลดจากเว็บไซต์**
1. ไปที่ https://www.python.org/downloads/
2. ดาวน์โหลด Python สำหรับ macOS
3. ติดตั้งตามขั้นตอน

### ขั้นตอนที่ 2: แตกไฟล์โปรเจกต์

1. แตกไฟล์ `SoraGen.zip` (double-click)
2. เปิด Terminal (กด Cmd+Space แล้วพิมพ์ "Terminal")
3. เข้าไปยังโฟลเดอร์โปรเจกต์:
```bash
cd ~/Downloads/SoraGen
# หรือ drag โฟลเดอร์ใส่ใน Terminal หลังพิมพ์ cd และกด space
```

### ขั้นตอนที่ 3: ติดตั้ง Dependencies

```bash
pip3 install -r requirements.txt
```

**หมายเหตุ:** ถ้าเจอ error เรื่อง permissions ให้ใช้:
```bash
pip3 install --user -r requirements.txt
```

### ขั้นตอนที่ 4: ตั้งค่า API Key

1. คัดลอกไฟล์ตัวอย่าง:
```bash
cp .env.example .env
```

2. แก้ไขไฟล์ `.env`:
```bash
nano .env
# หรือ
open -e .env
```

3. ใส่ OpenAI API Key ของคุณ:
```
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxx
```

4. บันทึกและออก:
   - สำหรับ `nano`: กด Ctrl+X, พิมพ์ Y, กด Enter
   - สำหรับ TextEdit: กด Cmd+S และปิดหน้าต่าง

### ขั้นตอนที่ 5: รันโปรแกรม

```bash
python3 main.py
```

**เปิดเบราว์เซอร์ไปที่:** http://127.0.0.1:8000

**หยุดโปรแกรม:** กด `Ctrl+C` ใน Terminal

---

## 🎯 การใช้งาน

1. **เปิดเบราว์เซอร์:** http://127.0.0.1:8000

2. **ตรวจสอบสถานะ:**
   - ถ้าเห็น "✓ API Key พร้อมใช้งาน" แสดงว่าพร้อมแล้ว
   - ถ้าเห็น "✗ ยังไม่ได้ตั้งค่า API Key" ให้ตรวจสอบไฟล์ `.env`

3. **สร้างวีดีโอ:**
   - กรอก Prompt อธิบายวีดีโอ (ภาษาอังกฤษแนะนำ)
   - เลือก Model: `Sora 2` (แนะนำ)
   - เลือกขนาด: `720x1280` (Vertical) สำหรับมือถือ
   - เลือกระยะเวลา: `8 วินาที` (แนะนำ)
   - กดปุ่ม "สร้างวีดีโอ"

4. **รอผลลัพธ์:**
   - ใช้เวลาประมาณ 1-3 นาที
   - วีดีโอจะแสดงใน player เมื่อเสร็จ
   - สามารถดาวน์โหลดได้ทันที

5. **วีดีโอที่สร้างแล้ว:**
   - บันทึกใน folder `videos/`
   - สามารถเปิดดูได้ตลอดเวลา

---

## 🔧 แก้ปัญหาที่พบบ่อย

### ❌ "pip: command not found" (macOS/Linux)

ใช้ `pip3` แทน `pip`:
```bash
pip3 install -r requirements.txt
```

### ❌ "python: command not found" (macOS/Linux)

ใช้ `python3` แทน `python`:
```bash
python3 main.py
```

### ❌ Port 8000 ถูกใช้งานอยู่แล้ว

**Windows:**
```cmd
netstat -ano | findstr :8000
taskkill /PID [PID_NUMBER] /F
```

**macOS/Linux:**
```bash
lsof -ti:8000 | xargs kill -9
```

หรือเปลี่ยน port ในไฟล์ `main.py` (บรรทัดสุดท้าย):
```python
uvicorn.run(app, host="127.0.0.1", port=8001)  # เปลี่ยนเป็น 8001
```

### ❌ "OPENAI_API_KEY not configured"

1. ตรวจสอบว่ามีไฟล์ `.env` (ไม่ใช่ `.env.example`)
2. เปิดไฟล์ `.env` และตรวจสอบว่ามี API Key
3. API Key ต้องไม่มี space หรือเครื่องหมายคำพูด
4. Restart server (กด Ctrl+C แล้วรันใหม่)

### ❌ "Failed to download video content"

- ตรวจสอบ internet connection
- ตรวจสอบว่า API Key ยังใช้งานได้
- ตรวจสอบว่ามี credits เพียงพอใน OpenAI account

### ❌ Video ไม่แสดง / ดาวน์โหลดไม่ได้

- ตรวจสอบว่ามีไฟล์ในโฟลเดอร์ `videos/`
- ลอง refresh หน้าเว็บ (F5 หรือ Cmd+R)
- ตรวจสอบ console logs ของ server

---

## 📚 ข้อมูลเพิ่มเติม

### วิธีรับ OpenAI API Key

1. ไปที่ https://platform.openai.com/
2. สมัครสมาชิกหรือเข้าสู่ระบบ
3. ไปที่ **API Keys** ในเมนู
4. กดปุ่ม **Create new secret key**
5. คัดลอก API Key (จะแสดงครั้งเดียวเท่านั้น!)
6. เติมเงินเข้า account (ต้องมี credits)

**หมายเหตุ:**
- Sora API อาจต้องรอ waitlist หรือ invitation
- ตรวจสอบว่า account ของคุณมี access ถึง Sora API
- ค่าใช้จ่ายขึ้นอยู่กับ model และระยะเวลาวีดีโอ

### ค่าใช้จ่าย (โดยประมาณ)

- **Sora 2**: ~$0.10-0.20 ต่อวีดีโอ 8 วินาที
- ขึ้นอยู่กับ resolution และ model ที่เลือก
- ตรวจสอบ pricing ล่าสุดที่: https://openai.com/pricing

### โครงสร้างโปรเจกต์

```
SoraGen/
├── main.py              # FastAPI backend server
├── index.html           # Frontend UI
├── requirements.txt     # Python dependencies
├── .env.example         # Template สำหรับ API key
├── .env                 # API key จริง (ต้องสร้างเอง)
├── .gitignore          # Git ignore rules
├── videos/             # วีดีโอที่สร้างแล้ว
├── README.md           # เอกสารโครงการ
└── INSTALL.md          # คู่มือนี้
```

---

## 🆘 ขอความช่วยเหลือ

หากพบปัญหาในการติดตั้งหรือใช้งาน:

1. อ่านส่วน "แก้ปัญหาที่พบบ่อย" ด้านบน
2. ตรวจสอบ error messages ใน Terminal/Command Prompt
3. ตรวจสอบว่าทำตามขั้นตอนครบถ้วน
4. ลองรัน server ใหม่

---

## 📄 License

MIT License - ใช้งานได้ตามสบาย!

---

**เวอร์ชัน:** 1.0.0
**อัพเดทล่าสุด:** พฤศจิกายน 2025
**ภาษา:** ไทย/English
