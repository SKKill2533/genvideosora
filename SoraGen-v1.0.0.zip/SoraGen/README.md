# 🎬 SoraGen - Video Generator

เว็บแอพสร้างวีดีโอด้วย AI ผ่าน OpenAI Sora API สำหรับใช้งานบน local

## ✨ Features

- สร้างวีดีโอจาก text prompt ด้วย OpenAI Sora
- รองรับ Sora 2 และ Sora 1.0 Turbo
- UI ภาษาไทยที่ใช้งานง่าย
- ตั้งค่า resolution และ duration ได้
- ดาวน์โหลดวีดีโอที่สร้างได้ทันที

## 🚀 การติดตั้ง

### 1. ติดตั้ง Dependencies

```bash
pip install -r requirements.txt
```

### 2. ตั้งค่า API Key

สร้างไฟล์ `.env` (copy จาก `.env.example`):

```bash
cp .env.example .env
```

แก้ไขไฟล์ `.env` และใส่ OpenAI API Key:

```
OPENAI_API_KEY=your_api_key_here
```

**วิธีรับ API Key:**
1. ไปที่ https://platform.openai.com/
2. สมัครสมาชิกหรือเข้าสู่ระบบ
3. ไปที่ API Keys
4. สร้าง API Key ใหม่และ copy มาใส่
5. ตรวจสอบว่ามี access และ credits สำหรับ Sora API

### 3. รัน Server

```bash
python main.py
```

หรือ

```bash
uvicorn main:app --reload
```

Server จะรันที่: http://127.0.0.1:8000

### 4. เปิดเว็บเบราว์เซอร์

เปิด: http://127.0.0.1:8000

## 📖 วิธีใช้งาน

1. **กรอก Prompt**: อธิบายวีดีโอที่ต้องการสร้างเป็นภาษาอังกฤษ
   - ตัวอย่าง: "A serene landscape with mountains, flowing river, and sunset"

2. **เลือก Model**:
   - `sora-2` - รุ่นล่าสุด (แนะนำ)
   - `sora-1.0-turbo` - เร็วกว่า

3. **ตั้งค่า Resolution**: เลือกขนาดวีดีโอที่ต้องการ
   - 1920x1080 (Full HD)
   - 1280x720 (HD)
   - 1080x1920 (Vertical/Portrait)

4. **กดปุ่ม "สร้างวีดีโอ"**: รอสักครู่ (อาจใช้เวลา 1-3 นาที)

5. **ดาวน์โหลด**: เมื่อวีดีโอพร้อม คุณสามารถดูและดาวน์โหลดได้ทันที

## 🔧 โครงสร้างโปรเจกต์

```
SoraGen/
├── main.py              # FastAPI backend
├── index.html           # Frontend UI
├── requirements.txt     # Python dependencies
├── .env                 # API key configuration (ต้องสร้างเอง)
├── .env.example         # Template สำหรับ .env
└── README.md           # เอกสารนี้
```

## 📝 API Endpoints

### GET `/`
- แสดงหน้า HTML หลัก

### GET `/api/health`
- ตรวจสอบสถานะ server และ API key
- Response: `{"status": "ok", "api_key_configured": true}`

### POST `/api/generate-video`
- สร้างวีดีโอจาก prompt
- Request body:
  ```json
  {
    "prompt": "your prompt here",
    "model": "sora-2",
    "size": "1920x1080",
    "duration": 5
  }
  ```
- Response:
  ```json
  {
    "video_url": "https://...",
    "status": "success",
    "message": "Video generated successfully"
  }
  ```

## ⚠️ หมายเหตุ

- OpenAI Sora API เป็น service ที่เสียค่าใช้จ่าย ต้องมี credits พอ
- การสร้างวีดีโอแต่ละครั้งอาจใช้เวลาและค่าใช้จ่ายแตกต่างกัน
- ต้องมี access ถึง Sora API (อาจต้องอยู่ใน waitlist)
- ควรอ่าน pricing และ limits ของ OpenAI ก่อนใช้งาน

## 🐛 แก้ปัญหา

### API Key ไม่ทำงาน
- ตรวจสอบว่าคัดลอก API key ถูกต้อง
- ตรวจสอบว่ามี credits เพียงพอใน OpenAI account
- ตรวจสอบว่ามี access ถึง Sora API

### Model ไม่รองรับ
- บาง model อาจไม่รองรับ video generation
- ลองเปลี่ยนเป็น model อื่นๆ ที่รองรับ

### Server ไม่ทำงาน
- ตรวจสอบว่าติดตั้ง dependencies ครบถ้วน
- ตรวจสอบว่า port 8000 ไม่ถูกใช้งานอยู่

## 📚 Resources

- [OpenAI Platform](https://platform.openai.com/)
- [OpenAI Sora](https://openai.com/sora)
- [OpenAI API Documentation](https://platform.openai.com/docs)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)

## 📄 License

MIT License - ใช้งานได้ตามสบาย!
